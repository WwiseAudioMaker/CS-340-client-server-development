from pymongo import MongoClient

class CRUD(object):
    """ CRUD operations for MongoDB """

    def __init__(self, user, password, host, port, db, collection):
        # Initialize Connection
        self.client = MongoClient(f'mongodb://{user}:{password}@{host}:{port}')
        self.database = self.client[db]
        self.collection = self.database[collection]

    def create(self, data):
        """Insert a document into the specified MongoDB database and collection."""
        if data:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        else:
            raise Exception("Nothing to save because the data parameter is empty")

    def read(self, query):
        """Query for documents from the specified MongoDB database and collection."""
        result = list(self.collection.find(query))
        return result if result else []
