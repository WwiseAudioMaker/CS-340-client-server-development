from crud_module import CRUD

# Connection Variables
USER = 'root'
PASS = 'hbaG98WkC8'
HOST = 'nv-desktop-services.apporto.com'
PORT = 31902
DB = 'aac'
COL = 'animals'

# Instantiate CRUD class
crud_instance = CRUD(USER, PASS, HOST, PORT, DB, COL)
