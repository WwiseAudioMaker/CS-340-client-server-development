from crud_module import CRUD

# Connection Variables
USER = 'root'
PASS = 'hbaG98WkC8'
HOST = 'nv-desktop-services.apporto.com'
PORT = 31902
DB = 'aac'
COL = 'animals'

# Instantiate CRUD class
crud_instance = CRUD(USER, PASS, HOST, PORT, DB, COL)

# Example Create
data_to_insert = {"name": "Test Animal", "type": "Test Type", "age": 3}
insert_result = crud_instance.create(data_to_insert)
print(f"Create Result: {insert_result}")

# Example Read
query_criteria = {"name": "Test Animal"}
read_result = crud_instance.read(query_criteria)
print(f"Read Result: {read_result}")

# Example Update
update_criteria = {"name": "Test Animal"}
update_data = {"age": 4}
update_result = crud_instance.update(update_criteria, update_data)
print(f"Update Result: {update_result}")

# Example Read after Update
read_result_after_update = crud_instance.read(query_criteria)
print(f"Read Result after Update: {read_result_after_update}")

# Example Delete
delete_criteria = {"name": "Test Animal"}
delete_result = crud_instance.delete(delete_criteria)
print(f"Delete Result: {delete_result}")

# Example Read after Delete
read_result_after_delete = crud_instance.read(query_criteria)
print(f"Read Result after Delete: {read_result_after_delete}")
