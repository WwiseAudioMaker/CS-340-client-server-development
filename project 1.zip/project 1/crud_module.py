from pymongo import MongoClient

class CRUD(object):
    """ CRUD operations for MongoDB """

    def __init__(self, user, password, host, port, db, collection):
        # Initialize Connection
        self.client = MongoClient(f'mongodb://{user}:{password}@{host}:{port}')
        self.database = self.client[db]
        self.collection = self.database[collection]

    def create(self, data):
        """Insert a document into the specified MongoDB database and collection."""
        if data:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        else:
            raise Exception("Nothing to save because the data parameter is empty")

    def read(self, query):
        """Query for documents from the specified MongoDB database and collection."""
        result = list(self.collection.find(query))
        return result if result else []

    def update(self, query, update_data):
        """Update document(s) in the specified MongoDB database and collection."""
        if query and update_data:
            result = self.collection.update_many(query, {'$set': update_data})
            return result.modified_count
        else:
            raise Exception("Update operation requires both query and update_data parameters")

    def delete(self, query):
        """Delete document(s) from the specified MongoDB database and collection."""
        if query:
            result = self.collection.delete_many(query)
            return result.deleted_count
        else:
            raise Exception("Delete operation requires a query parameter")
